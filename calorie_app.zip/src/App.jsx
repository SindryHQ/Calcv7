import React, { useState } from "react";

function calcBMR({ sex, weightKg, heightCm, age }) {
  if (sex === "male") return 10*weightKg + 6.25*heightCm - 5*age + 5;
  return 10*weightKg + 6.25*heightCm - 5*age - 161;
}
function activityMultiplier(level){
  return {sedentary:1.2,light:1.375,moderate:1.55,active:1.725,very:1.9}[level]||1.2;
}

export default function App(){
  const [form,setForm]=useState({weightKg:70,heightCm:175,age:30,sex:"male",activity:"moderate",goal:"maintain"});
  const [imageData,setImageData]=useState(null);
  const [analysis,setAnalysis]=useState(null);
  const [loading,setLoading]=useState(false);

  const bmr=calcBMR(form);
  const tdee=Math.round(bmr*activityMultiplier(form.activity));
  const recommended=form.goal==="lose"?Math.round(tdee*0.8):form.goal==="gain"?Math.round(tdee*1.15):tdee;

  const handleFile=e=>{
    const f=e.target.files?.[0]; if(!f)return;
    const r=new FileReader(); r.onload=()=>setImageData(r.result); r.readAsDataURL(f);
  };

  const sendForAnalysis=async()=>{
    if(!imageData)return alert("Загрузите фото");
    setLoading(true); setAnalysis(null);
    try{
      const body={imageBase64:imageData,userContext:{...form,recommendedCalories:recommended}};
      const resp=await fetch("/.netlify/functions/analyze",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(body)});
      const json=await resp.json(); setAnalysis(json);
    } catch(err){ setAnalysis({error:err.message}); }
    setLoading(false);
  };

  return (<div style={{maxWidth:820,margin:"24px auto",fontFamily:"Arial"}}>
    <h1>Calorie Tracker</h1>
    <section style={{padding:12,border:"1px solid #ddd",borderRadius:8}}>
      <h2>Профиль</h2>
      <label>Пол:<select value={form.sex} onChange={e=>setForm({...form,sex:e.target.value})}>
        <option value="male">Муж</option><option value="female">Жен</option></select></label><br/>
      <label>Вес:<input type="number" value={form.weightKg} onChange={e=>setForm({...form,weightKg:+e.target.value})}/></label><br/>
      <label>Рост:<input type="number" value={form.heightCm} onChange={e=>setForm({...form,heightCm:+e.target.value})}/></label><br/>
      <label>Возраст:<input type="number" value={form.age} onChange={e=>setForm({...form,age:+e.target.value})}/></label><br/>
      <label>Активность:<select value={form.activity} onChange={e=>setForm({...form,activity:e.target.value})}>
        <option value="sedentary">Сидячий</option><option value="light">Лёгкая</option>
        <option value="moderate">Умеренная</option><option value="active">Активная</option>
        <option value="very">Очень активная</option></select></label><br/>
      <label>Цель:<select value={form.goal} onChange={e=>setForm({...form,goal:e.target.value})}>
        <option value="lose">Похудеть</option><option value="maintain">Поддержать</option><option value="gain">Набрать</option></select></label>

      <div style={{marginTop:12}}>
        <b>BMR:</b> {Math.round(bmr)}<br/>
        <b>TDEE:</b> {tdee}<br/>
        <b>Реком. норма:</b> {recommended}
      </div>
    </section>

    <section style={{marginTop:16,padding:12,border:"1px solid #ddd",borderRadius:8}}>
      <h2>Фото еды</h2>
      <input type="file" accept="image/*" onChange={handleFile}/>
      {imageData && <img src={imageData} style={{maxWidth:"100%",marginTop:8}}/>}
      <button onClick={sendForAnalysis} disabled={loading} style={{marginTop:8}}>
        {loading?"Анализ...":"Отправить"}
      </button>
    </section>

    <section style={{marginTop:16}}>
      <h2>Результат</h2>
      {analysis?<pre>{JSON.stringify(analysis,null,2)}</pre>:"Пока пусто"}
    </section>
  </div>);
}
