const endpoint="https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent";
const API_KEY="AIzaSyBbYbzLU8MrxoQ2VvH2ZLOC1-t5SdxX9-E";

exports.handler=async function(event){
  if(event.httpMethod!=="POST")return{statusCode:405,body:"Method Not Allowed"};
  const body=JSON.parse(event.body);
  const img=body.imageBase64;
  const prompt=`Return ONLY JSON:
{
 "estimated_calories": <number>,
 "items":[{"name":"x","grams":100,"calories":200,"confidence":0.9}],
 "note":"..."
}`;

  const contents=[{inlineData:{mimeType:"image/jpeg",data:img.replace(/^data:image\/\w+;base64,/,"")}},{text:prompt}];

  const r=await fetch(endpoint+"?key="+API_KEY,{
    method:"POST",
    headers:{"Content-Type":"application/json"},
    body:JSON.stringify({contents})
  });
  const j=await r.json();
  let modelText=JSON.stringify(j);
  try{modelText=j.candidates[0].content;}catch(e){}

  let parsed=null;
  try{parsed=JSON.parse(modelText);}catch(e){}
  if(!parsed){ 
    const m=modelText.match(/\{[\s\S]*\}/);
    if(m){try{parsed=JSON.parse(m[0]);}catch(e){}}
  }
  return{statusCode:200,body:JSON.stringify({raw:modelText,parsed})};
};
